import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text(
            "K3522012",
            style: TextStyle(
              color: Colors.white,
              fontFamily: 'Arial',
            ),
          ),
          backgroundColor: const Color.fromARGB(255, 225, 92, 21),
          centerTitle: true,
        ),
        body: Center(
          child: Text(
            "BAGAS DWI PRASETYO",
            style: TextStyle(
              fontFamily: 'Arial Bold',
              fontSize: 24,
              color: const Color.fromARGB(255, 225, 92, 21),
            ),
          ),
        ),
        backgroundColor: const Color.fromARGB(255, 208, 210, 212),
        
        floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
        floatingActionButton: ElevatedButton.icon(
          onPressed: () {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('Button Pressed!'),
              ),
            );
          },
          icon: Icon(
            Icons.search,
            size: 20.0,
          ),
          label: Text(
            'Cari',
            style: TextStyle(
              fontSize: 14,
              color: Colors.white,
            ),
          ),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.blue, 
          ),
        ),

        drawer: Drawer(
          backgroundColor: Color.fromARGB(255, 255, 255, 255),
          child: SafeArea(
            child: Column(
              children: [
                ListTile(
                  leading: Icon(Icons.list),
                  title: Text("Lists"),
                ),
                ListTile(
                  leading: Icon(Icons.settings),
                  title: Text("Settings"),
                ),
                ListTile(
                  leading: Icon(Icons.login),
                  title: Text("Login"),
                ),
              ],
            ),
          ),
        ),

        // Bottom Navigation Bar dengan dua item
        bottomNavigationBar: BottomNavigationBar(
          items: [
            BottomNavigationBarItem(
              icon: Icon(Icons.add),
              label: "Tambah",
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.delete),
              label: "Hapus",
            ),
          ],
        ),
      ),
    );
  }
}
